package recuperatorioparcial1_sandes;

public class naveExistenteException extends RuntimeException {
    public naveExistenteException(String mes){
        super(mes);
    }
}

