package recuperatorioparcial1_sandes;

public class CruceroEstelar extends Nave {
    private int capacidadPasajeros;

    public CruceroEstelar(String nombre, int capacidad, String fecha_lanz, int capacidadPasajeros) {
        super(nombre, capacidad, fecha_lanz);
        this.capacidadPasajeros = capacidadPasajeros;
    }

    @Override
    public String toString() {
        return "CruceroEstelar{" + "capacidadPasajeros=" + capacidadPasajeros + '}';
    }
    
    @Override
    public void explorar() {
        System.out.println(getNombre() + " No puede explorar.");
    }
}
