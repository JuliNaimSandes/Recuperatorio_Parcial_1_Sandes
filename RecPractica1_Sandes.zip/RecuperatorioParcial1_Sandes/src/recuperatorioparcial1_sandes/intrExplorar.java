package recuperatorioparcial1_sandes;

public interface intrExplorar {
    void explorar();
}
