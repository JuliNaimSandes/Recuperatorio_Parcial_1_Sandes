package recuperatorioparcial1_sandes;

import java.util.Objects;

public abstract class Nave implements intrExplorar {
    private String nombre;
    private int capacidad;
    private String fecha_lanz;
    
    //Constructor
    public Nave(String nombre, int capacidad, String fecha_lanz) {
        this.nombre = nombre;
        this.capacidad = capacidad;
        this.fecha_lanz = fecha_lanz;
    }

    //Getters
    public int getCapacidad() {
        return capacidad;
    }

    public String getNombre() {
        return nombre;
    }
    
    //Hashcode y Equals.
    @Override
    public int hashCode(){
        return Objects.hash(nombre);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        
        //Condiciones
        if(obj instanceof String str){
            return nombre.equals(str);
        }
        if(obj instanceof Nave nav){
            return nombre.equals(nav.getNombre());
        }
        return false;
    }
}
