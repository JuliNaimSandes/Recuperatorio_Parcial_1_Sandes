package recuperatorioparcial1_sandes;

public class naveExploracion extends Nave {
    private tipoMision mision;

    public naveExploracion(String nombre, int capacidad, String fecha_lanz, tipoMision mision) {
        super(nombre, capacidad, fecha_lanz);
        this.mision = mision;
    }
    
    @Override
    public void explorar() {
        System.out.println(getNombre() + " comenzo a Explorar - Mision: " + mision);
    }

    @Override
    public String toString() {
        return "naveExploracion{" + "mision=" + mision + '}';
    }
}
