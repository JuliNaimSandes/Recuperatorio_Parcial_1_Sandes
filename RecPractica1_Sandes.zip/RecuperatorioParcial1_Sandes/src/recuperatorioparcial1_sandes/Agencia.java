package recuperatorioparcial1_sandes;

import java.util.ArrayList;

public class Agencia {
    private ArrayList<Nave> naves;
    
    //Constructor
    public Agencia() {
        this.naves = new ArrayList<>();
    }
    
    //Metodos
    public void agregarNave(Nave nv){
        try{
            //Que sea una nueva.
            if(naveYaExistente(nv)){
                throw new naveExistenteException("Nave ya ingresada.");
            }else
            {
                naves.add(nv);
            }
        }
        catch (Exception ex){
            throw(ex);
        }
    }
    
    public void mostrarNaves(){
        for (Nave nv : naves) {
            System.out.println(nv.toString());
        }
    }
    
    public void iniciarExploracion(){
        for (Nave nv : naves) {
            nv.explorar();
        }
    }
    
    private boolean naveYaExistente(Nave nv){
        boolean r = false;
        
        for (Nave nv2 : naves) {
            if(nv.equals(nv2)){
                r = true;
                break;
            }
        }
        
        return r;
    }
}
