package recuperatorioparcial1_sandes;

public class Carguero extends Nave {
    private int capacidadCarga;

    public Carguero(String nombre, int capacidad, String fecha_lanz, int capacidadCarga) {
        super(nombre, capacidad, fecha_lanz);
        this.capacidadCarga = capacidadCarga;
    }

    @Override
    public void explorar() {
        System.out.println(getNombre() + " comenzo a Explorar.");
    }

    @Override
    public String toString() {
        return "Carguero{" + "capacidadCarga=" + capacidadCarga + '}';
    }
}
