package recuperatorioparcial1_sandes;

public enum tipoMision {
    CARTOGRAFIA,
    MISION,
    EXPLORACION
}
