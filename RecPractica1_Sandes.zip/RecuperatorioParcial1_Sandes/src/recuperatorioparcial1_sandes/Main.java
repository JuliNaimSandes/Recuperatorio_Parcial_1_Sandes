
package recuperatorioparcial1_sandes;

public class Main {

    public static void main(String[] args) {
        //Testing
        Agencia a = new Agencia();
        a.agregarNave(new Carguero("Nave1", 100, "10/8/2024", 3));
        a.agregarNave(new naveExploracion("Nave2", 50, "6/6/2024", tipoMision.EXPLORACION));
        a.agregarNave(new CruceroEstelar("Nave3", 75, "2/8/2024", 50));
        a.agregarNave(new naveExploracion("Nave4", 50, "6/6/2024", tipoMision.MISION));
        
        //Llamado de metodos que imprimiran.
        a.mostrarNaves();
        a.iniciarExploracion();
    }
    
}
